package fr.eql.autom.modele.proprietes;

public interface IPropriete {
	
	public String getValeur();
	
	public String getNom();
}
