package fr.eql.autom.dictionary;

public class DictionnaireTest {

}
