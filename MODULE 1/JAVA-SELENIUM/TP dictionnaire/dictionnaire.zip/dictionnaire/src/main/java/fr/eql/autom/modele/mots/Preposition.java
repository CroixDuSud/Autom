package fr.eql.autom.modele.mots;

import fr.eql.autom.modele.entrees.Entree;

public class Preposition extends Mot {

	public Preposition(Entree lexeme, String forme) {
		super(lexeme, forme);
	}

}
