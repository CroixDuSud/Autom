package fr.eql.autom.modele.mots;

import fr.eql.autom.modele.entrees.Entree;

public class Adverbe extends Mot {

	public Adverbe(Entree lexeme, String forme) {
		super(lexeme, forme);
	}

}
